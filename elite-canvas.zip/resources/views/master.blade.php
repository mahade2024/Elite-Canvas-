<!DOCTYPE html>
<html lang="en">
<head>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elite Canvas</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        /* =========================================
           1. LAYOUT (master.blade.php)
           ========================================= */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            background-color: #f8f9fa; /* Light grey background for the whole site */
        }
        .main-content {
            flex: 1;
        }
        /*Header Nav bar 01 --- header.blade.php Custom Styles --- */
        .navbar-custom {
            background-color: #ffffff;
            padding: 15px 0;
        }

        .search-form {
            width: 50%; /* Makes search bar prominent */
        }

        .search-input {
            border-radius: 20px 0 0 20px;
            border: 1px solid #ddd;
            padding-left: 20px;
        }

        .btn-search {
            border-radius: 0 20px 20px 0;
            background-color: #b1ca3a; /* Your Lime Green */
            color: white;
            border: 1px solid #b1ca3a;
            padding: 0 20px;
        }

        .btn-search:hover {
            background-color: #9ab332;
            color: white;
        }

        .social-icon {
            margin-left: 15px;
            transition: 0.3s;
            display: inline-block !important;
            color: #000000 !important; 
            font-size: 24px !important;
            min-width: 24px;
            min-height: 24px;
        }

        .fb:hover { color: #1877F2 !important; } /* Facebook Blue */
        .wa:hover { color: #25D366 !important; } /* WhatsApp Green */

        /*Header Nav bar 02 (header.blade.php)*/
          .navbar-nav .nav-link {
            color: white !important; /* Forces text to be black */
            opacity: 1 !important;     /* Removes the transparency Bootstrap usually adds */
        }

        .navbar-nav .nav-link:hover {
            color: #ffffff !important; /* Optional: text turns white when you hover */
        } 

        /* =========================================
           2. LOGIN PAGE (login.blade.php)
           ========================================= */
        .page-bg {
            background-color: #f9c3db; /* Pink Background */
            min-height: calc(100vh - 100px); /* Adjusts for header/footer */
            width: 100%;
            display: flex;
            align-items: center; 
            justify-content: center;
        }
        .login-card {
            background-color: #b1ca3a; /* Lime Green Card */
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        /* =========================================
           3. SLIDER SECTION (product.blade.php)
           ========================================= */
        body {
        background-color: #F9C3DB;

        .slider-img {
            height: 400px !important;
            object-fit: cover; 
            border-radius: 10px;
        }
        .slider-text {
            background-color: rgba(0, 0, 0, 0.4); 
            border-radius: 10px;
            padding: 15px;
            bottom: 30px;
        }

        /* =========================================
           4. TRENDING GRID (product.blade.php)
           ========================================= */
        .trending-wrapper {
            margin: 40px auto;
            padding: 0 15px;
            max-width: 1200px;
        }
        .trending-item {
            margin-bottom: 30px;
            text-align: center;
            transition: transform 0.3s ease;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .trending-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .trending-image {
            width: 100%;
            height: 150px; 
            object-fit: contain;
            margin-bottom: 10px;
        }
        .price-text {
            color: #f45424; /* Orange Price */
            font-weight: bold;
            margin-top: 5px;
        }
        /* Quick View Button Style */
        .btn-outline-teal {
            color: #086d7e;
            border: 2px solid #086d7e;
            background-color: transparent;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            border-radius: 4px;
        }

        .btn-outline-teal:hover {
            background-color: #086d7e;
            color: #ffffff !important;
            box-shadow: 0 4px 8px rgba(8, 109, 126, 0.3);
            transform: translateY(-1px);
        }
        

        /* --- detail.blade.php Styles --- */
            .btn-variant-box {
        border: 1px solid #086d7e;
        color: #086d7e;
        font-size: 13px;
        border-radius: 2px;
        padding: 5px 12px;
        }
        .btn-check:checked + .btn-variant-box {
            background-color: #086d7e;
            color: white;
        }
        .price-display {
            font-size: 32px;
            font-weight: bold;
            color: #d9534f;
            background: #f8d7da;
            padding: 5px 20px;
            border-radius: 4px;
        }
        .btn-teal { background-color: #086d7e; }
        .btn-teal:hover { background-color: #065461; }
        .text-teal { color: #086d7e; }
        
        .thumb-box { width: 80px; height: 80px; cursor: pointer; padding: 2px; }
        .active-thumb { border: 2px solid #086d7e !important; }
        
        .quantity-input input::-webkit-outer-spin-button,
        .quantity-input input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }

        #mainImage {
                        transition: opacity 0.3s ease-in-out;
                        object-fit: cover;
                        aspect-ratio: 1/1; /* Keeps all images the same size */
                    }

                    .active-thumb {
                        border: 2px solid #008080 !important; /* Teal highlight */
                    }
        
        /* cartlist.blade.php--General Cart Container */
        
       
        .cart-table thead { background-color: #f8f9fa; border-top: 2px solid #086d7e; }
        .cart-product-img { width: 80px; height: 80px; object-fit: cover; border-radius: 5px; }
        .btn-qty { background: #eee; border: 1px solid #ddd; width: 30px; height: 30px; cursor: pointer; }
        .qty-input { width: 40px; text-align: center; border: 1px solid #ddd; height: 30px; margin: 0 -5px; }
        .btn-checkout { background-color: #086d7e; color: white; padding: 10px 30px; font-weight: bold; }
        .btn-checkout:hover { background-color: #065461; color: white; }
        .remove-link { text-decoration: none; font-size: 12px; }


        /* Checkout Theme Colors */
        .btn-submit-order {
            background-color: #006b7d; /* Teal Color from your image */
            color: white;
            padding: 12px;
            font-size: 1.1rem;
            font-weight: bold;
            border: none;
            border-radius: 4px;
        }

        .btn-submit-order:hover {
            background-color: #005a69;
            color: white;
        }

        /* Form Controls */
        .form-control, .form-select {
            border: 1px solid #ced4da;
            border-radius: 2px;
            padding: 10px;
        }

        .input-group-text {
            background-color: #f8f9fa;
            color: #6c757d;
        }

        /* Cart Summary Sidebar */
        .cart-summary-box {
            border-radius: 4px;
        }

        .text-info {
            color: #17a2b8 !important;
        }
        /*myorders.blade.php*/
            .hover-shadow:hover {
        transform: translateY(-2px);
        transition: 0.3s;
        box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
    }
    .border-dashed {
        border: 2px dashed #dee2e6;
    }


        /* about.blade.php --- About US Page */

        /* Individual Hero Section CSS */
    .hero-section {
        background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), 
                    url('{{ asset('images/1.png') }}'); /* Replace with your image path */
        background-size: cover;
        background-position: center;
        background-attachment: fixed; /* Parallax effect */
        height: 60vh;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        text-align: center;
    }

    .hero-title {
        font-size: 3.5rem;
        font-weight: 800;
        text-shadow: 2px 2px 10px rgba(0,0,0,0.5);
    }

    .hero-subtitle {
        font-size: 1.25rem;
        max-width: 700px;
        margin: 20px auto;
    }
         .about-header {
        color: #1aa1a5;
        }

        .step-card {
            transition: all 0.3s ease;
            border-left: 5px solid #1aa1a5 !important;
        }

        .step-card:hover {
            transform: translateX(10px);
            background-color: #f0f9f9;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
        }

        .feature-img {
            transition: transform 0.5s ease;
        }

        .feature-img:hover {
            transform: scale(1.03);
        }

        .menu-card {
            border: none;
            border-radius: 15px;
            transition: 0.3s;
        }

        .menu-card:hover {
            background-color: #ffffff;
            box-shadow: 0 8px 20px rgba(26, 161, 165, 0.15) !important;
        }

        .text-brand {
            color: #1aa1a5 !important;
        }

        .bg-brand-light {
            background-color: rgba(26, 161, 165, 0.05);
        }
        /* services.blade.php --Services Page Specific Styling */
                /* Individual Hero CSS for Services */
        .services-hero {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('{{ asset('images/2.png') }}'); /* Ensure this path is correct */
            background-size: cover;
            background-position: center;
            padding: 100px 0;
            color: white;
            margin-bottom: -50px; /* Pulls cards slightly up into the hero area for modern look */
        }

        .service-card {
            border-radius: 20px !important;
            transition: all 0.3s ease-in-out;
            border: none !important;
            background: white;
        }

        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15) !important;
        }

        .icon-box {
            width: 80px;
            height: 80px;
            background: rgba(26, 161, 165, 0.1);
            border-radius: 50%;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s;
        }

        .service-card:hover .icon-box {
            background: #1aa1a5;
        }

        .service-card:hover .icon-box i {
            color: white !important;
        }

        body {
    background-color: #f8f9fa;
}

    </style>
    @yield('styles')
</head>
<body>
    {{ View::make('header') }}

    <div class="main-content">
        @yield("content") 
    </div>

    {{ View::make('footer') }}

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    @yield('scripts')
</body>
</html>