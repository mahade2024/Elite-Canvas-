@extends('master')
@section('content')

<div class="page-bg flex-column">
    {{-- 1. Check if there are products to show --}}
    @if($products->count() > 0) 

    <div class="container custom-products py-5">
        <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                @foreach ($products as $key => $item)
                <button type="button" data-bs-target="#productCarousel" data-bs-slide-to="{{$key}}" class="{{$key == 0 ? 'active' : ''}}" aria-current="true"></button>
                @endforeach
            </div>

            <div class="carousel-inner">
                @foreach ($products as $key => $item)
                <div class="carousel-item {{$key == 0 ? 'active' : ''}}">
                    <a href="detail/{{$item['id']}}">
                      <img src="{{asset($item['gallery'])}}" class="d-block w-100 slider-img" alt="{{$item['name']}}">
                      <div class="carousel-caption d-none d-md-block slider-text">
                          <h3>{{$item['name']}}</h3>
                          <p>{{$item['description']}}</p>  
                      </div>
                    </a>
                </div>
                @endforeach
            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    <div class="container-fluid px-0">
        <div class="trending-wrapper container"> {{-- Added container for padding --}}
            <h1 class="text-center mb-5">Trending Products</h1>
            
            <div class="row g-3"> 
                @foreach ($products as $item)
                <div class="col-6 col-md-4 col-lg-3"> 
                    <div class="trending-item p-2 border rounded shadow-sm h-100">
                        <a href="detail/{{$item['id']}}" class="text-decoration-none text-dark">
                            <img class="trending-image img-fluid rounded" src="{{asset($item['gallery'])}}" alt="{{$item['name']}}">
                            <div class="mt-2">
                                <h6 class="fw-bold mb-1">{{$item['name']}}</h6>
                                <p class="price-text mb-2 text-teal fw-bold">{{$item['price']}} BDT</p>
                            </div>
                        </a>

                        <div class="mt-auto">
                            <a href="detail/{{$item['id']}}" class="btn btn-sm btn-outline-teal w-100 py-2">
                                Quick View
                            </a>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>

    @else
        {{-- 2. Show this if NO products are found (Empty State) --}}
        <div class="container">
            <div class="text-center py-5">
                <h1 class="display-1 text-muted">🍽️</h1>
                <h2 class="fw-bold">No Dishes Found!</h2>
                <p class="text-secondary">We couldn't find anything matching your search. Try searching for "Biryani" or "Dessert".</p>
                <a href="/" class="btn btn-warning mt-3">View All Products</a>
            </div>
        </div>
    @endif

</div> {{-- Close page-bg --}}

@endsection