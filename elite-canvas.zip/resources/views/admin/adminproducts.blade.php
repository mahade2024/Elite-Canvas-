@extends('admin.admin_master') 

@section('content')

    {{-- Success Message --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-dark mb-0">Menu Management</h2>
        <button class="btn btn-dark shadow-sm px-4 py-2" data-bs-toggle="modal" data-bs-target="#addProductModal">
            <i class="bi bi-plus-lg me-2"></i> Add New Package
        </button>
    </div>

    {{-- Product Table --}}
    <div class="card shadow-sm border-0 w-100">
        <div class="card-header bg-dark text-white py-3">
            <h5 class="mb-0 small fw-bold text-uppercase">Current Inventory</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr class="small text-uppercase">
                            <th class="ps-4">Image</th>
                            <th>Product Name</th>
                            <th>Category</th>
                            <th>Variants</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($products as $product)
                        <tr>
                            <td class="ps-4">
                                <img src="{{asset($product->gallery)}}" width="50" height="50" class="rounded border shadow-sm object-fit-cover">
                            </td>
                            <td class="fw-bold text-dark">{{$product->name}}</td>
                            <td><span class="badge bg-info text-dark">{{$product->category}}</span></td>
                            <td>
                                <span class="badge bg-secondary">{{ $product->variants->count() }} Days Set</span>
                            </td>
                            <td class="text-center">
                                <form action="/delete-product" method="POST" onsubmit="return confirm('Remove this package?')">
                                    @csrf
                                    <input type="hidden" name="id" value="{{$product->id}}">
                                    <button class="btn btn-sm btn-outline-danger border-0">
                                        <i class="bi bi-trash3-fill"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- Modal --}}
    <div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title fw-bold">Add Variable Product</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form action="/add-product" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body p-4">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label small fw-bold">PRODUCT NAME</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label small fw-bold">CATEGORY</label>
                                <select name="category" class="form-select">
                                    <option value="Package1">Package 1</option>
                                    <option value="Package2">Package 2</option>
                                    <option value="Package3">Package 3</option>
                                    <option value="Diet">Diet</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">MAIN THUMBNAIL (From Device)</label>
                            <input type="file" name="gallery" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-bold">DESCRIPTION</label>
                            <textarea name="description" class="form-control" rows="2" required></textarea>
                        </div>

                        <hr>
                        <h6 class="fw-bold text-primary mb-3"><i class="bi bi-camera me-2"></i>Daily Menus</h6>
                        
                        <div class="row g-3">
                            @foreach(['SAT', 'SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI'] as $day)
                            <div class="col-md-6 col-lg-4">
                                <div class="card border p-3 variant-card" style="background-color: #f8f9fa; transition: 0.3s;">
                                    <div class="form-check mb-2">
                                        <input class="form-check-input day-checkbox" type="checkbox" name="variant_names[]" value="{{ $day }}" id="day_{{ $day }}">
                                        <label class="form-check-label fw-bold" for="day_{{ $day }}">{{ $day }}</label>
                                    </div>
                                    
                                    {{-- Removed pointer-events: none to fix the mouse selection issue --}}
                                    <div class="variant-inputs" style="opacity: 0.4;">
                                        <div class="input-group input-group-sm mb-2">
                                            <span class="input-group-text">৳</span>
                                            <input type="number" name="variant_prices[]" class="form-control price-input" placeholder="Price" disabled>
                                        </div>
                                        <input type="file" name="variant_images[]" class="form-control form-control-sm image-input" disabled>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-dark px-5">Save Full Package</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    document.querySelectorAll('.day-checkbox').forEach((checkbox) => {
        checkbox.addEventListener('change', function() {
            const card = this.closest('.variant-card');
            const inputSection = card.querySelector('.variant-inputs');
            const priceInput = card.querySelector('.price-input');
            const imageInput = card.querySelector('.image-input');

            if (this.checked) {
                // ENABLE
                inputSection.style.opacity = "1";
                card.style.backgroundColor = "#fff";
                card.style.borderColor = "#0d6efd";
                priceInput.disabled = false;
                imageInput.disabled = false;
                priceInput.required = true;
                priceInput.focus();
            } else {
                // DISABLE & CLEAR
                inputSection.style.opacity = "0.4";
                card.style.backgroundColor = "#f8f9fa";
                card.style.borderColor = "#dee2e6";
                priceInput.disabled = true;
                imageInput.disabled = true;
                priceInput.required = false;
                priceInput.value = '';
                imageInput.value = '';
            }
        });
    });
    </script>
@endsection