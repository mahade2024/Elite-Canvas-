@php
    use App\Models\Cart;
    use Illuminate\Support\Facades\Session;

    $count = 0;
    if(Session::has('user')) {
        $count = Cart::where('user_id', Session::get('user')['id'])->count();
    } else {
        $count = Session::has('cart') ? count(Session::get('cart')) : 0;
    }
@endphp

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<nav class="navbar navbar-expand-lg bg-white border-bottom py-2">
    <div class="container d-flex justify-content-between align-items-center">
        <form action="/search" class="d-flex" style="width: 50%;"> 
            <input name="query" class="form-control" type="search" placeholder="Search delicious food..." style="border-radius: 20px 0 0 20px;">
            <button class="btn btn-dark" type="submit" style="border-radius: 0 20px 20px 0;">Search</button>
        </form>

        <div class="d-flex align-items-center">
        <a class="nav-link px-2" href="https://www.facebook.com/Elitecanvasbd" target="_blank" rel="noopener noreferrer" style="color: #1877F2; font-size: 1.2rem;">
            <i class="bi bi-facebook"></i>
        </a>

        <a class="nav-link px-2" href="https://wa.me/+8801731012053" target="_blank" rel="noopener noreferrer" style="color: #25D366; font-size: 1.2rem;">
            <i class="bi bi-whatsapp"></i>
        </a>
        </div>
    </div>
</nav>

<nav class="navbar navbar-expand-lg shadow-sm" style="background-color: #a72e23; height:60px;" data-bs-theme="dark">
  <div class="container d-flex align-items-center justify-content-between">
    
    <a class="navbar-brand" href="{{ url('/') }}">
    <img src="{{ asset('images/elitelogo.png') }}" alt="Elite Canvas Logo" style="width:100px; height: 100px; object-fit: contain;">
    </a>

    <ul class="navbar-nav mx-auto d-flex flex-row mb-0">
        <li class="nav-item"><a class="nav-link text-white px-2" href="{{ route('products.index') }}">HOME</a></li>
        <li class="nav-item"><a class="nav-link text-white px-2" href="#">STANDARD</a></li>
        <li class="nav-item"><a class="nav-link text-white px-2" href="#">DIET</a></li>
        <li class="nav-item"><a class="nav-link text-white px-3" href="{{ route('services') }}">SERVICES</a></li>
        <li class="nav-item"><a class="nav-link text-white px-2" href="{{ route('about') }}">ABOUT US</a></li>
        
        @if(Session::has('user'))
            <li class="nav-item"><a class="nav-link text-white px-2" href="/myorders">MY ORDERS</a></li>
            
            @if(Session::get('user')['role'] == 1)
                <li class="nav-item">
                    <a class="nav-link text-warning fw-bold px-2" href="/admin/orders">
                        <i class="bi bi-speedometer2"></i> ADMIN PANEL
                    </a>
                </li>
            @endif
        @endif
    </ul>

    <ul class="navbar-nav ms-auto d-flex flex-row align-items-center mb-0">
        <li class="nav-item">
            <a class="nav-link bg-light rounded-circle d-flex align-items-center justify-content-center position-relative shadow-sm" href="/cartlist" style="width: 40px; height: 40px;">
                <i class="bi bi-cart3 text-dark fs-5"></i>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">
                    {{ $count }}
                </span>
            </a>
        </li>

        @if(Session::has('user'))
            <li class="nav-item ms-3">
                <a class="nav-link text-white" href="/logout">LOGOUT</a>
            </li>
        @else
            <li class="nav-item ms-3">
                <a class="nav-link text-white fw-bold" href="/login">LOGIN</a>
            </li>
            <li class="nav-item ms-2">
                <a class="nav-link text-white fw-bold" href="/register">SIGNUP</a>
            </li>
        @endif
    </ul>
  </div>
</nav>