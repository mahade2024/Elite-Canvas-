<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory; // Added this import
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
   use HasFactory;
    public $table = "cart"; 
    
}